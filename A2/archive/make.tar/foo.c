/* foo.c - implementation of functions, definition of global vars
 * 
 * CS265/571
 *
 */

#include <stdio.h>

char *myEnvVar = "FOO_ENV";

void wallOfVoodoo( char *s )
{
	printf( "FOO> And the penquin yelled, \"%s\"\n", s );
}

