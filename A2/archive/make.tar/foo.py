#!/usr/bin/python

print "This is the foo in Python."
print "Say *that* 5 times, in rapid succession."
print ""

