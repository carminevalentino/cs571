/* foo.h - header file for functions found in bar
 * 
 * CS265/571
 *
 */

extern char *myEnvVar;

void wallOfVoodoo( char* );

